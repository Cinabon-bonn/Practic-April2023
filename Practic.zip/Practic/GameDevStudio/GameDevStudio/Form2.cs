﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GameDevStudio
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void signInButton(object sender, EventArgs e)
        {
            StreamWriter f = new StreamWriter("Logins.txt", false);
            f.WriteLine(comboBox1.Text);
            f.Close();
            if ((comboBox1.Text == "Admin") && (textBox1.Text == "111"))
            {
                MessageBox.Show("Welcome Admin!");
                Form4 form4 = new Form4();
                form4.Show();
            }
            else if ((comboBox1.Text == "Designer") && (textBox1.Text == "222"))
            {
                MessageBox.Show("Welcome Designer!");
                Form4 form4 = new Form4();
                form4.Show();
            }
            else if ((comboBox1.Text == "Developer") && (textBox1.Text == "333"))
            {
                MessageBox.Show("Welcome Developer!");
                Form4 form4 = new Form4();
                form4.Show();
            }
            else if ((comboBox1.Text == "Accountant") && (textBox1.Text == "444"))
            {
                MessageBox.Show("Welcome Accountant!");
                Form4 form4 = new Form4();
                form4.Show();
            }
            else if ((comboBox1.Text == "HR") && (textBox1.Text == "555"))
            {
                MessageBox.Show("Welcome HR!");
                Form4 form4 = new Form4();
                form4.Show();
            }
            else
            {
                MessageBox.Show("Invalid password. Please, try again");
            }
        }
    }
}
